$ go run for.go
1
2
3
7
8
9
loop
1
3
5

# We'll see some other `for` forms later when we look at
# `range` statements, channels, and other data
# structures.
