$ go run channel-directions.go
passed message
