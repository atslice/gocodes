$ go run recursion.go 
5040
13
