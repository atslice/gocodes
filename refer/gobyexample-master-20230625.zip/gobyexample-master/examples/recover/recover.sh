$ go run recover.go
Recovered. Error:
 a problem
