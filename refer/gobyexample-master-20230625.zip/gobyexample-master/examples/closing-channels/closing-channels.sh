$ go run closing-channels.go 
sent job 1
received job 1
sent job 2
received job 2
sent job 3
received job 3
sent all jobs
received all jobs

# The idea of closed channels leads naturally to our next
# example: `range` over channels.
