// The first timer will fire ~2s after we start the
// program, but the second should be stopped before it has
// a chance to fire.
$ go run timers.go
Timer 1 fired
Timer 2 stopped
