$ go run if-else.go 
7 is odd
8 is divisible by 4
9 has 1 digit

# There is no [ternary if](https://en.wikipedia.org/wiki/%3F:)
# in Go, so you'll need to use a full `if` statement even
# for basic conditions.
