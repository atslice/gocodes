$ go run generics.go
keys: [4 1 2]
list: [10 13 23]
